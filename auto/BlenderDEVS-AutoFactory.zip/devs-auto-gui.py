#!BPY

""" Registration info for Blender menus:
Name: 'CD++ Simulations'
Blender: 241
Group: 'Simulations'
Tooltip: 'CD++ Auto Factory DEVS Simulations'
"""

# --------------------------------------------------------------------------
# ***** BEGIN GPL LICENSE BLOCK *****
#
# Copyright (C) 2007 Emil Poliakov aka NiTeC
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# 
#
# ***** END GPL LICENCE BLOCK *****
# --------------------------------------------------------------------------

__author__ = "Emil Poliakov"
__version__ = "1.0.1"

__bpydoc__ = """
CD++ Simulations 1.0.1

With this script you can load the CD++ Simulations results into Blender and apply them to objects etc.


"""




# Modified by Kin Wing Tsui - Dec 2007
# To animate the auto factory DEVS model

import Blender  # This will import the library of blender functions we will use
from Blender import Draw, BGL, Window, Image, Scene, Object, Ipo
from Blender.Scene import Render

# General Constants
winsize = Window.GetAreaSize()
logfilename = ""
mafilename = ""

# Animation Constants and Variables
fps = 25			# frames per second
animSeconds = 1		# length of animation in seconds
deceleration = 0.2	# deceleration factor (must be < 1)
washout = 2			# number of frames at the end to move object back to initial location (in a hidden layer)
lastAnimationFrame = 1	# to be changed by log file

# Scene Constants
curScene = Scene.GetCurrent()
autoFactoryLayer = 1
engineFactoryLayer = 2
partsLayer = 4

# Get Handle to Objects
ObjProductPlan1 = Object.Get('ProductPlan1')
ObjProductPlan2 = Object.Get('ProductPlan2')
ObjProductPlan3 = Object.Get('ProductPlan3')
ObjProductPlan4 = Object.Get('ProductPlan4')
ObjEnginePlan1 = Object.Get('EnginePlan1')
ObjEnginePlan2 = Object.Get('EnginePlan2')
ObjChassis = Object.Get('Chassis')
ObjCarBody = Object.Get('CarBody')
ObjTransmission = Object.Get('Transmission')
ObjPiston = Object.Get('Piston')
ObjEngineBody = Object.Get('EngineBody')
ObjEngineAsm = Object.Get('EngineAsm')
ObjEngine = Object.Get('Engine')
ObjCar = Object.Get('Car')

# Locations: Start/End
LocSProductPlan1 = [-30, 0, 0]
LocSProductPlan2 = [-30, 0, 0]
LocSProductPlan3 = [-30, 0, 0]
LocSProductPlan4 = [-30, 0, 0]
LocSChassis      = [5, 25, 0]
LocSCarBody      = [5, 15, 0]
LocSTransmission = [4, 5, 0]
LocSEngine       = [12, -15, 0]
LocSCar          = [27, 5, 0]
LocSEnginePlan1  = [-8.185, -15, 0]
LocSEnginePlan2  = [-8.185, -15, 0]
LocSPiston       = [-0.5, -10, 0]
LocSEngineBody   = [0, -20, 0]
LocSEngineAsm    = [10, -15, 0]

LocEProductPlan1 = [-4, 25, 0]
LocEProductPlan2 = [-4, 15, 0]
LocEProductPlan3 = [-4, 5, 0]
LocEProductPlan4 = [-12, -15, 0]
LocEChassis      = [17, 5, 0]
LocECarBody      = [17, 5, 0]
LocETransmission = [18, 5, 0]
LocEEngine       = [18, 5, 0]
LocECar          = [35, 5, 0]
LocEEnginePlan1  = [-8.185, -10, 0]
LocEEnginePlan2  = [-8.185, -20, 0]
LocEPiston       = [2, -15, 0]
LocEEngineBody   = [1, -15, 0]
LocEEngineAsm    = [14, -15, 0]

# Create Ipos
IpoProductPlan1 = Ipo.New('Object', 'IpoProductPlan1')
IpoProductPlan2 = Ipo.New('Object', 'IpoProductPlan2')
IpoProductPlan3 = Ipo.New('Object', 'IpoProductPlan3')
IpoProductPlan4 = Ipo.New('Object', 'IpoProductPlan4')
IpoEnginePlan1 = Ipo.New('Object', 'IpoEnginePlan1')
IpoEnginePlan2 = Ipo.New('Object', 'IpoEnginePlan2')
IpoChassis = Ipo.New('Object', 'IpoChassis')
IpoCarBody = Ipo.New('Object', 'IpoCarBody')
IpoTransmission = Ipo.New('Object', 'IpoTransmission')
IpoPiston = Ipo.New('Object', 'IpoPiston')
IpoEngineBody = Ipo.New('Object', 'IpoEngineBody')
IpoEngineAsm = Ipo.New('Object', 'IpoEngineAsm')
IpoEngine = Ipo.New('Object', 'IpoEngine')
IpoCar = Ipo.New('Object', 'IpoCar')

# Add IPO curves to the IPO objects (X, Y, Layer)
IpoProductPlan1.addCurve('LocX')
IpoProductPlan2.addCurve('LocX')
IpoProductPlan3.addCurve('LocX')
IpoProductPlan4.addCurve('LocX')
IpoEnginePlan1.addCurve('LocX')
IpoEnginePlan2.addCurve('LocX')
IpoChassis.addCurve('LocX')
IpoCarBody.addCurve('LocX')
IpoTransmission .addCurve('LocX')
IpoPiston.addCurve('LocX')
IpoEngineBody .addCurve('LocX')
IpoEngineAsm.addCurve('LocX')
IpoEngine.addCurve('LocX')
IpoCar.addCurve('LocX')

IpoProductPlan1.addCurve('LocY')
IpoProductPlan2.addCurve('LocY')
IpoProductPlan3.addCurve('LocY')
IpoProductPlan4.addCurve('LocY')
IpoEnginePlan1.addCurve('LocY')
IpoEnginePlan2.addCurve('LocY')
IpoChassis.addCurve('LocY')
IpoCarBody.addCurve('LocY')
IpoTransmission .addCurve('LocY')
IpoPiston.addCurve('LocY')
IpoEngineBody .addCurve('LocY')
IpoEngineAsm.addCurve('LocY')
IpoEngine.addCurve('LocY')
IpoCar.addCurve('LocY')

# initialize layers (at frame 1) to partsLayer
layerCurve = IpoProductPlan1.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoProductPlan2.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoProductPlan3.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoProductPlan4.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoEnginePlan1.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoEnginePlan2.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoChassis.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoCarBody.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoTransmission .addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoPiston.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoEngineBody .addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoEngineAsm.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoEngine.addCurve('Layer')
layerCurve[0] = partsLayer
layerCurve = IpoCar.addCurve('Layer')
layerCurve[0] = partsLayer

# --------------------------------------------------------------------------
# animObject(obj, curLayer, loc1, loc2, frame)
#
# Add animation to an event
#
# objName :		Name of the object to animate (Type: string)
# curLayer :	Layer in which the object will appear (Type: int)
# loc1 :		Initial location (Type: list of 3 ints)
# loc2 :		Final location (Type: list of 3 ints)
# frame :		Current frame number (Type: int)
# --------------------------------------------------------------------------
def animObject(objName, curLayer, loc1, loc2, frame):

	global fps, animSeconds, deceleration, washout, partsLayer
	global ObjProductPlan1, ObjProductPlan2, ObjProductPlan3, ObjProductPlan4, ObjEnginePlan1, ObjEnginePlan2
	global ObjChassis, ObjCarBody, ObjTransmission, ObjPiston, ObjEngineBody, ObjEngineAsm, ObjEngine, ObjCar

	if (objName == "ProductPlan1"):
		objIpo = IpoProductPlan1
	elif (objName == "ProductPlan2"):
		objIpo = IpoProductPlan2
	elif (objName == "ProductPlan3"):
		objIpo = IpoProductPlan3
	elif (objName == "ProductPlan4"):
		objIpo = IpoProductPlan4
	elif (objName == "EnginePlan1"):
		objIpo = IpoEnginePlan1
	elif (objName == "EnginePlan2"):
		objIpo = IpoEnginePlan2
	elif (objName == "Chassis"):
		objIpo = IpoChassis
	elif (objName == "CarBody"):
		objIpo = IpoCarBody
	elif (objName == "Transmission"):
		objIpo = IpoTransmission
	elif (objName == "Piston"):
		objIpo = IpoPiston
	elif (objName == "EngineBody"):
		objIpo = IpoEngineBody
	elif (objName == "EngineAsm"):
		objIpo = IpoEngineAsm
	elif (objName == "Engine"):
		objIpo = IpoEngine
	elif (objName == "Car"):
		objIpo = IpoCar
	else:
		return

	# For debugging purposes
	print objName + " (layer = " + str(curLayer) + ", frame = " + str(frame) + ")"

	# Calculate animation variables
	durationInFrame   = int(fps * animSeconds)
	firstFrame        = int(frame)
	lastFrame         = firstFrame + durationInFrame
	decelFrame        = int(lastFrame - (deceleration * durationInFrame))
	washoutFrame      = int(lastFrame - washout)

	# Ipo for X
	#objLCurve = objIpo[Ipo.OB_LOCX] # not supported by this version of Blender
	objXCurve = objIpo.getCurve('LocX')
	objXCurve[firstFrame]   = loc1[0]
	objXCurve[decelFrame]   = loc1[0] + 0.98 * (loc2[0] - loc1[0])
	objXCurve[washoutFrame] = loc2[0]
	objXCurve[lastFrame]    = loc1[0]
	objXCurve.recalc()

	# Ipo for Y
	#objLCurve = objIpo[Ipo.OB_LOCY]
	objYCurve = objIpo.getCurve('LocY')
	objYCurve[firstFrame]   = loc1[1]
	objYCurve[decelFrame]   = loc1[1] + 0.98 * (loc2[1] - loc1[1])
	objYCurve[washoutFrame] = loc2[1]
	objYCurve[lastFrame]    = loc1[1]
	objYCurve.recalc()

	# Ipo for Layer (Washout - move object back to initial location)
	#objLCurve = objIpo[Ipo.OB_LAYER]
	objLCurve = objIpo.getCurve('Layer')
	objLCurve[firstFrame]   = int(curLayer)
	objLCurve[washoutFrame] = partsLayer
	objLCurve.recalc()

# --------------------------------------------------------------------------
# finalizeObjects()
#
# Assign data to objects after reading log file
# --------------------------------------------------------------------------
def finalizeObjects():

	global ObjProductPlan1, ObjProductPlan2, ObjProductPlan3, ObjProductPlan4, ObjEnginePlan1, ObjEnginePlan2
	global ObjChassis, ObjCarBody, ObjTransmission, ObjPiston, ObjEngineBody, ObjEngineAsm, ObjEngine, ObjCar

	# Assign Ipo objects
	ObjProductPlan1.setIpo(IpoProductPlan1)
	ObjProductPlan2.setIpo(IpoProductPlan2)
	ObjProductPlan3.setIpo(IpoProductPlan3)
	ObjProductPlan4.setIpo(IpoProductPlan4)
	ObjEnginePlan1.setIpo(IpoEnginePlan1)
	ObjEnginePlan2.setIpo(IpoEnginePlan2)
	ObjChassis.setIpo(IpoChassis)
	ObjCarBody.setIpo(IpoCarBody)
	ObjTransmission.setIpo(IpoTransmission)
	ObjPiston.setIpo(IpoPiston)
	ObjEngineBody.setIpo(IpoEngineBody)
	ObjEngineAsm.setIpo(IpoEngineAsm)
	ObjEngine.setIpo(IpoEngine)
	ObjCar.setIpo(IpoCar)

	# Redraw scene
	Blender.Redraw()


# --------------------------------------------------------------------------
# setupAnimation()
#
# Prepare Blender for animating DEVS model
# --------------------------------------------------------------------------
def setupAnimation():

	global lastAnimationFrame, fps

	renderContext = curScene.getRenderingContext()
	renderContext.endFrame(lastAnimationFrame)
	renderContext.framesPerSec(fps)

# --------------------------------------------------------------------------
# read_log(path)
#
# Read and parse CD++ log file
#
# path : full path of the CD++ log file
# --------------------------------------------------------------------------
def read_log(path):
	
	Blender.Window.WaitCursor(1)	
	file = open(path, "r")
	for line in file.readlines():
		words = line.split()
		if words[1] == ("X"):
			time      = words[3]
			srcModel  = words[5]
			port      = words[7]
			valueWord = words[9]
			destModel = words[11]
			apply_log(srcModel, destModel, time, port, valueWord)
		if words[1] == ("Y"):
			time      = words[3]
			srcModel  = words[5]
			port      = words[7]
			valueWord = words[9]
			destModel = words[11]
			apply_log(srcModel, destModel, time, port, valueWord)
	Blender.Window.WaitCursor(0)

# --------------------------------------------------------------------------
# apply_log(srcName, destName, time, port, valueWord)
#
# Interpret CD++ log file data for Blender animation
#
# srcName :		name of the model that sent the CD++ message
# destName :	name of the model that received the CD++ message
# time :		timestamp of the message
# port :		port through which this message was received
# valueWord :	string containing the numeric value in the message
# --------------------------------------------------------------------------
def apply_log(srcName, destName, time, port, valueWord):

	global lastAnimationFrame
	global autoFactoryLayer, engineFactoryLayer
	global ObjProductPlan1, ObjProductPlan2, ObjProductPlan3, ObjProductPlan4, ObjEnginePlan1, ObjEnginePlan2
	global ObjChassis, ObjCarBody, ObjTransmission, ObjPiston, ObjEngineBody, ObjEngineAsm, ObjEngine, ObjCar
	global LocSProductPlan1, LocSProductPlan2, LocSProductPlan3, LocSProductPlan4, LocSEnginePlan1, LocSEnginePlan2
	global LocSChassis, LocSCarBody, LocSTransmission, LocSPiston, LocSEngineBody, LocSEngineAsm, LocSEngine, LocSCar
	global LocEProductPlan1, LocEProductPlan2, LocEProductPlan3, LocEProductPlan4, LocEEnginePlan1, LocEEnginePlan2
	global LocEChassis, LocECarBody, LocETransmission, LocEPiston, LocEEngineBody, LocEEngineAsm, LocEEngine, LocECar

	# --------------------------------------------------
	# Assign local variables
	# --------------------------------------------------
	# Get model names
	p = srcName.find( '(' )
	srcModel = srcName[:p]
	p = destName.find( '(' )
	destModel = destName[:p]

	# Get time
	hours	 = int(time[0:2])
	minutes   = int(time[3:5])
	seconds   = int(time[6:8])
	## mseconds = int(time[9:12])
	## totaltime = ( hours*3600 + minutes*60 + seconds*10 + mseconds )
	## For the Auto Factory DEVS, mseconds are always 0
	## Furthermore, for real-time runs, Blender can only handle a maximum of 120 fps
	totaltime = ( hours*3600 + minutes*60 + seconds )

	# Get value
	## In Auto Factory DEVS, the port values will always be integers
	p = valueWord.find( '.' )
	value = int(valueWord[:p])

	# Set current frame value
	curFrame = int(totaltime * fps * animSeconds) + 1
	if (lastAnimationFrame < curFrame): lastAnimationFrame = curFrame

	# For debugging purposes
	print "Model: " + srcModel + "->" + destModel + " (" + str(value) + "@" + port + ") at " + str(totaltime) + " seconds = frame " + str(curFrame)

	# --------------------------------------------------
	# Determine animation behaviour
	# --------------------------------------------------
	if (value >= 1):
		if (srcModel == "top"):
			if (destModel == "chassis"):
				if (port == "in"): animObject("ProductPlan1", autoFactoryLayer, LocSProductPlan1, LocEProductPlan1, curFrame)
			elif (destModel == "body"):
				if (port == "in"): animObject("ProductPlan2", autoFactoryLayer, LocSProductPlan2, LocEProductPlan2, curFrame)
			elif (destModel == "trans"):
				if (port == "in"): animObject("ProductPlan3", autoFactoryLayer, LocSProductPlan3, LocEProductPlan3, curFrame)
			elif (destModel == "enginesubfact"):
				if (port == "in"): animObject("ProductPlan4", autoFactoryLayer, LocSProductPlan4, LocEProductPlan4, curFrame)
		elif (srcModel == "enginesubfact"):
			if (destModel == "piston"):
				if (port == "in"): animObject("EnginePlan1", engineFactoryLayer, LocSEnginePlan1, LocEEnginePlan1, curFrame)
			elif (destModel == "enginebody"):
				if (port == "in"): animObject("EnginePlan2", engineFactoryLayer, LocSEnginePlan2, LocEEnginePlan2, curFrame)
			elif (destModel == "top"):
				if (port == "out"): animObject("Engine", autoFactoryLayer, LocSEngine, LocEEngine, curFrame)
		elif (srcModel == "chassis"):
			if (destModel == "top"):
				if (port == "out"): animObject("Chassis", autoFactoryLayer, LocSChassis, LocEChassis, curFrame)
		elif (srcModel == "body"):
			if (destModel == "top"):
				if (port == "out"): animObject("CarBody", autoFactoryLayer, LocSCarBody, LocECarBody, curFrame)
		elif (srcModel == "trans"):
			if (destModel == "top"):
				if (port == "out"): animObject("Transmission", autoFactoryLayer, LocSTransmission, LocETransmission, curFrame)
		elif (srcModel == "piston"):
			if (destModel == "enginesubfact"):
				if (port == "out"): animObject("Piston", engineFactoryLayer, LocSPiston, LocEPiston, curFrame)
		elif (srcModel == "enginebody"):
			if (destModel == "enginesubfact"):
				if (port == "out"): animObject("EngineBody", engineFactoryLayer, LocSEngineBody, LocEEngineBody, curFrame)
		elif (srcModel == "engineass"):
			if (destModel == "enginesubfact"):
				if (port == "out"): animObject("EngineAsm", engineFactoryLayer, LocSEngineAsm, LocEEngineAsm, curFrame)
		elif (srcModel == "finalass"):
			if (destModel == "top"):
				if (port == "out"): animObject("Car", autoFactoryLayer, LocSCar, LocECar, curFrame)

# --------------------------------------------------------------------------
# initAnim(path)
#
# Read the CD++ log file and set up the animation
#
# path : full path of the CD++ log file
# --------------------------------------------------------------------------
def initAnim(path):
	read_log(path)
	finalizeObjects()
	setupAnimation()

# --------------------------------------------------------------------------
# import_file2(ma)
#
# Saves the CD++ MA file path
#
# ma : MA file path to be saved
# --------------------------------------------------------------------------
def import_file2(ma):
	global mafilename
	mafilename = ma
	Draw.Redraw(1)
	
# --------------------------------------------------------------------------
# import_file2(log)
#
# Saves the CD++ log file path
#
# log : log file path to be saved
# --------------------------------------------------------------------------
def import_file3(log):
	global logfilename
	logfilename = log
	Draw.Redraw(1)

# --------------------------------------------------------------------------
# event(evt, val)
#
# Keyboard and mouse event handler
# --------------------------------------------------------------------------
def event(evt, val):  
	return

# --------------------------------------------------------------------------
# buttonHandler(evt)
#
# Button-click handler
# --------------------------------------------------------------------------
def buttonHandler(evt): 
	global logfilename, mafilename
	default_name = Blender.Get('filename')
	ma_name = default_name[0:len(default_name)-len("untitled.blend")] + ('*.ma')
	log_name = default_name[0:len(default_name)-len("untitled.blend")] + ('*.log')
	if evt == 1:	
		Blender.Window.FileSelector(import_file2, "Select",ma_name)
	if evt == 2:
		Blender.Window.FileSelector(import_file3, "Select", log_name)
	if evt == 3:
		initAnim(logfilename)
	if evt == 4:
		curScene.play()

# --------------------------------------------------------------------------
# gui()
#
# Main initial user interface of the script
# --------------------------------------------------------------------------
def gui():
	global mafilename, logfilename, loginfo
	BGL.glClearColor(0,0,0,1)
	BGL.glClear(BGL.GL_COLOR_BUFFER_BIT)
	BGL.glColor3f(1,1,1) 

	BGL.glRasterPos2i(10, (winsize[1]-110))
	text1 = Draw.Text("Select MA File", 'normal')
	log_toggle = Draw.Toggle("Browse",1,10,(winsize[1]-140),100,20,0,"Import the CD++ MA File")
	BGL.glRasterPos2i(140, (winsize[1]-140))
	text1 = Draw.Text(mafilename, 'normal')

	BGL.glRasterPos2i(10, (winsize[1]-160))
	text2 = Draw.Text("Select LOG File", 'normal')
	ma_toggle = Draw.Toggle("Browse",2,10,(winsize[1]-190),100,20,0,"Import the CD++ Generated LOG File")
	BGL.glRasterPos2i(140, (winsize[1]-190))
	text1 = Draw.Text(logfilename, 'normal')

	load_toggle = Draw.Toggle("Load",3,10,(winsize[1]-300),100,20,0,"Load CD++ Files")

	execute_toggle = Draw.Toggle("Execute",4,10,(winsize[1]-350),100,20,0,"Start the Blender Visualization")
 

# Register user interface and user event handlers
Blender.Draw.Register(gui, event, buttonHandler)
	


#!BPY